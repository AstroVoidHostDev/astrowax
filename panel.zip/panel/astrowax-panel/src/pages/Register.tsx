// @ts-nocheck
import React, { useState } from "react";
import { LoadingOverlay } from "../components/LoadingOverlay";
import { useSettings } from "../context/SettingsContext";
import { useNavigate, Link } from "react-router-dom";
import axios from "axios";
import "./Register.css";

export default function Register() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const { panelName, enableRegistration } = useSettings();
  const navigate = useNavigate();

  const getStrength = () => {
    if (!password) return { level: 0, label: "", color: "" };
    let score = 0;
    if (password.length >= 6) score++;
    if (password.length >= 10) score++;
    if (/[A-Z]/.test(password)) score++;
    if (/[0-9]/.test(password)) score++;
    if (/[^A-Za-z0-9]/.test(password)) score++;
    if (score <= 1) return { level: 1, label: "Weak", color: "#ef4444" };
    if (score === 2) return { level: 2, label: "Fair", color: "#f59e0b" };
    if (score === 3) return { level: 3, label: "Good", color: "#eab308" };
    if (score === 4) return { level: 4, label: "Strong", color: "#22c55e" };
    return { level: 5, label: "Excellent", color: "#16a34a" };
  };
  const strength = getStrength();

  const handleRegister = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    if (enableRegistration === false) {
      setError("Registration is disabled.");
      return;
    }
    if (!username.trim()) { setError("Username is required"); return; }
    if (username.trim().length < 3) { setError("Username must be at least 3 characters"); return; }
    if (password !== confirmPassword) { setError("Passwords do not match"); return; }
    if (password.length < 6) { setError("Password must be at least 6 characters"); return; }

    setIsLoading(true);
    try {
      await axios.post("/api/auth/register", {
        username: username.trim(),
        password,
        confirmPassword,
      });
      setSuccess("Account created! Redirecting...");
      setTimeout(() => navigate("/login"), 1500);
    } catch (err) {
      setError(err.response?.data?.error || "Registration failed.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="aw-auth-root">
      {/* VIDEO BACKGROUND */}
      <video
        className="aw-auth-video"
        src="https://motionbgs.com/media/10092/minecraft-fishing.960x540.mp4"
        autoPlay
        loop
        muted
        playsInline
        preload="auto"
      />

      {/* OVERLAY */}
      <div className="aw-auth-overlay" />

      {/* CONTENT */}
      <div className="aw-auth-content">
        <div className="aw-auth-card">
          <div className="aw-auth-header">
            <h2 className="aw-auth-title">Create Account</h2>
            <p className="aw-auth-subtitle">{panelName || "AstroWax"} — Join the panel</p>
          </div>

          <form onSubmit={handleRegister} className="aw-auth-form">
            {enableRegistration === false && (
              <div className="aw-auth-error">Registration is disabled.</div>
            )}
            {error && <div className="aw-auth-error">{error}</div>}
            {success && <div className="aw-auth-success">{success}</div>}

            <div className="aw-auth-field">
              <label className="aw-auth-label">Username</label>
              <input
                type="text"
                required
                placeholder="Choose a username"
                className="aw-auth-input"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                autoComplete="username"
                disabled={isLoading}
              />
            </div>

            <div className="aw-auth-field">
              <label className="aw-auth-label">Password</label>
              <input
                type="password"
                required
                placeholder="Create a password"
                className="aw-auth-input"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="new-password"
                disabled={isLoading}
              />
              {password && (
                <div className="aw-auth-strength">
                  <div className="aw-auth-strength-bars">
                    {[1, 2, 3, 4, 5].map((i) => (
                      <span
                        key={i}
                        className="aw-auth-strength-bar"
                        style={{ background: i <= strength.level ? strength.color : "rgba(168,85,247,.15)" }}
                      />
                    ))}
                  </div>
                  <span className="aw-auth-strength-label" style={{ color: strength.color }}>
                    {strength.label}
                  </span>
                </div>
              )}
            </div>

            <div className="aw-auth-field">
              <label className="aw-auth-label">Confirm Password</label>
              <input
                type="password"
                required
                placeholder="Re-enter your password"
                className="aw-auth-input"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                autoComplete="new-password"
                disabled={isLoading}
              />
              {confirmPassword && password !== confirmPassword && (
                <p className="aw-auth-mismatch">Passwords do not match</p>
              )}
            </div>

            <button
              type="submit"
              className="aw-auth-submit"
              disabled={
                isLoading ||
                !!success ||
                enableRegistration === false ||
                (!!confirmPassword && password !== confirmPassword)
              }
            >
              {isLoading ? "Creating account..." : "Create Account"}
            </button>
          </form>

          <div className="aw-auth-footer">
            Already have an account?{" "}
            <Link to="/login" className="aw-auth-link">Sign in</Link>
          </div>
        </div>
      </div>

      {isLoading && <LoadingOverlay message="Creating account..." />}
    </div>
  );
}