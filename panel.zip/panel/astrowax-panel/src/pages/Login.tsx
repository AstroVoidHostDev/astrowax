// @ts-nocheck
import React, { useState } from "react";
import { LoadingOverlay } from "../components/LoadingOverlay";
import { useAuth } from "../context/AuthContext";
import { useSettings } from "../context/SettingsContext";
import { useNavigate, Link } from "react-router-dom";
import axios from "axios";
import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, signInWithPopup } from "firebase/auth";
import "./Login.css";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const { login } = useAuth();
  const {
    panelName, enableRegistration,
    enableGoogleLogin, firebaseApiKey, firebaseAuthDomain, firebaseProjectId,
    firebaseStorageBucket, firebaseMessagingSenderId, firebaseAppId,
  } = useSettings();
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");
    try {
      const res = await axios.post("/api/auth/login", { username, password });
      const { token, user } = res.data || {};
      if (!token || !user || !user.id) {
        setError("Invalid server response.");
        return;
      }
      login(token, user);
      navigate("/");
    } catch (err) {
      setError(err.response?.data?.error || "Login failed");
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    if (!firebaseApiKey || !firebaseProjectId) {
      setError("Firebase Google Login is not configured.");
      return;
    }
    setIsLoading(true);
    setError("");
    try {
      const fbConfig = {
        apiKey: firebaseApiKey, authDomain: firebaseAuthDomain,
        projectId: firebaseProjectId, storageBucket: firebaseStorageBucket,
        messagingSenderId: firebaseMessagingSenderId, appId: firebaseAppId,
      };
      const app = getApps().length === 0 ? initializeApp(fbConfig) : getApp();
      const auth = getAuth(app);
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      const gu = result.user;
      if (!gu.email) throw new Error("No email associated");

      const res = await axios.post("/api/auth/google", {
        email: gu.email, googleId: gu.uid,
        name: gu.displayName || "", photoURL: gu.photoURL || "",
      });
      const { token, user } = res.data || {};
      if (!token || !user || !user.id) {
        setError("Invalid server response.");
        return;
      }
      login(token, user);
      navigate("/");
    } catch (err) {
      setError(err.response?.data?.error || err.message || "Google Auth failed.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="aw-auth-root">
      {/* ═══ VIDEO BACKGROUND (no blur = no lag) ═══ */}
      <video
        className="aw-auth-video"
        src="https://motionbgs.com/media/10092/minecraft-fishing.960x540.mp4"
        autoPlay
        loop
        muted
        playsInline
        preload="auto"
      />

      {/* ═══ DARK PURPLE OVERLAY (this gives the "blur" look cheaply) ═══ */}
      <div className="aw-auth-overlay" />

      {/* ═══ CONTENT ═══ */}
      <div className="aw-auth-content">
        <div className="aw-auth-card">
          <div className="aw-auth-header">
            <h2 className="aw-auth-title">{panelName || "AstroWax"} Login</h2>
            <p className="aw-auth-subtitle">Welcome back</p>
          </div>

          <form onSubmit={handleLogin} className="aw-auth-form">
            {error && <div className="aw-auth-error">{error}</div>}

            <div className="aw-auth-field">
              <label className="aw-auth-label">Username</label>
              <input
                type="text"
                required
                placeholder="Enter your username"
                className="aw-auth-input"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                autoComplete="username"
                disabled={isLoading}
              />
            </div>

            <div className="aw-auth-field">
              <label className="aw-auth-label">Password</label>
              <input
                type="password"
                required
                placeholder="Enter your password"
                className="aw-auth-input"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="current-password"
                disabled={isLoading}
              />
            </div>

            <button type="submit" className="aw-auth-submit" disabled={isLoading}>
              {isLoading ? "Signing in..." : "Sign In"}
            </button>
          </form>

          {enableGoogleLogin && (
            <button
              type="button"
              onClick={handleGoogleLogin}
              disabled={isLoading}
              className="aw-auth-google"
            >
              Continue with Google
            </button>
          )}

          {enableRegistration !== false && (
            <div className="aw-auth-footer">
              Don't have an account?{" "}
              <Link to="/register" className="aw-auth-link">Register</Link>
            </div>
          )}
        </div>
      </div>

      {isLoading && <LoadingOverlay message="Signing in..." />}
    </div>
  );
}