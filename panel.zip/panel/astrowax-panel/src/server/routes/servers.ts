import express from "express";
import path from "path";
import fs from "fs";
import multer from "multer";

import { importWorld, getWorldInfo, analyzeWorld } from "../controllers/world.js";
import { requireAuth } from "../middleware/auth.js";
import {
  getServers, createServer, checkPort, getServer, deleteServer,
  startServer, stopServer, restartServer, killServer,
  changeServerVersion, updateRuntime, migrateServerRuntime,
  getFiles, uploadFile, uploadChunk, completeUpload, deleteFile,
  renameFile, saveFileContent, sendCommand, getServerStats,
  updateOwner, updateIpAlias, getBackups, createBackup, downloadBackup,
  deleteBackup, restoreBackup, unzipFile, zipFiles,
  installPlugin, installMod, getInstalledPlugins, deleteInstalledPlugin,
  getInstalledMods, deleteInstalledMod, getModrinthProjectVersions,
  updateResources, updateSuspend, createFile, createDirectory, downloadFile
} from "../controllers/servers.js";

import { getContainerLogs } from "../services/docker.js";
import { getLocalServerLogs } from "../services/local.js";
import { createSftpUser, resetSftpPassword, getSftpUser, deleteSftpUser } from "../services/sftp.js";
import { readJSON, writeJSON } from "../services/db.js";

const router = express.Router();

// ─────────────────────────────────────────────
//  SETUP: Ensure temp upload dir exists
// ─────────────────────────────────────────────
const tempDir = path.join(process.cwd(), ".data", "temp");
if (!fs.existsSync(tempDir)) {
  fs.mkdirSync(tempDir, { recursive: true });
}

const upload = multer({
  dest: tempDir,
  limits: { fileSize: 2 * 1024 * 1024 * 1024 }, // 2 GB
});

// ─────────────────────────────────────────────
//  HELPERS
// ─────────────────────────────────────────────
const SERVERS_FILE = "servers.json";
const USERS_FILE = "users.json";

async function getServerById(id: string) {
  const servers = (await readJSON(SERVERS_FILE)) || [];
  return servers.find((s: any) => s.id === id) || null;
}

function canManageServer(user: any, server: any) {
  if (!user || !server) return false;
  if (user.role === "admin" || user.role === "owner") return true;
  return server.owner === user.id;
}

// ─────────────────────────────────────────────
//  AUTH MIDDLEWARE (applies to everything below)
// ─────────────────────────────────────────────
router.use(requireAuth);

// ═════════════════════════════════════════════
//  SERVER CRUD
// ═════════════════════════════════════════════
router.get("/", getServers);
router.get("/check-port", checkPort);
router.post("/", createServer);
router.get("/:id", getServer);
router.get("/:id/stats", getServerStats);
router.delete("/:id", deleteServer);
router.put("/:id/owner", updateOwner);
router.put("/:id/ipalias", updateIpAlias);
router.put("/:id/version", changeServerVersion);
router.put("/:id/runtime", updateRuntime);
router.put("/:id/migrate-runtime", migrateServerRuntime);
router.put("/:id/resources", updateResources);
router.put("/:id/suspend", updateSuspend);

// ═════════════════════════════════════════════
//  SERVER LIFECYCLE
// ═════════════════════════════════════════════
router.post("/:id/start", startServer);
router.post("/:id/stop", stopServer);
router.post("/:id/restart", restartServer);
router.post("/:id/kill", killServer);
router.post("/:id/command", sendCommand);

// ═════════════════════════════════════════════
//  FILE MANAGER
// ═════════════════════════════════════════════
router.get("/:id/files", getFiles);
router.get("/:id/files/download", downloadFile);
router.post("/:id/files/upload", upload.single("file"), uploadFile);
router.post("/:id/files/upload-chunk", upload.single("chunk"), uploadChunk);
router.post("/:id/files/upload-complete", completeUpload);
router.post("/:id/files/rename", renameFile);
router.post("/:id/files/save", saveFileContent);
router.post("/:id/files/create", createFile);
router.post("/:id/files/mkdir", createDirectory);
router.post("/:id/files/unzip", unzipFile);
router.post("/:id/files/zip", zipFiles);
router.delete("/:id/files", deleteFile);

// ═════════════════════════════════════════════
//  WORLD MANAGEMENT
// ═════════════════════════════════════════════
router.post("/:id/world/analyze", analyzeWorld);
router.post("/:id/world/import", importWorld);
router.get("/:id/world/info", getWorldInfo);

// ═════════════════════════════════════════════
//  BACKUPS
// ═════════════════════════════════════════════
router.get("/:id/backups", getBackups);
router.post("/:id/backups", createBackup);
router.get("/:id/backups/:filename", downloadBackup);
router.delete("/:id/backups/:filename", deleteBackup);
router.post("/:id/backups/:filename/restore", restoreBackup);

// ═════════════════════════════════════════════
//  LOGS
// ═════════════════════════════════════════════
router.get("/:id/logs", async (req, res) => {
  try {
    const { id } = req.params;
    const server = await getServerById(id);
    if (!server) return res.status(404).json({ error: "Server not found" });

    let logs = "";

    const localLogs = await getLocalServerLogs(id).catch(() => null);
    if (localLogs) logs += localLogs.trim() + "\n";

    if (server.containerId && !String(server.containerId).startsWith("local-")) {
      const dockerLogs = await getContainerLogs(server.containerId).catch(() => null);
      if (dockerLogs) logs += dockerLogs.trim() + "\n";
    }

    res.json({ logs });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ═════════════════════════════════════════════
//  PLAYIT TUNNEL
// ═════════════════════════════════════════════
function getPlayitName(server: any, id: string) {
  const serverName = server
    ? server.name.replace(/[^a-zA-Z0-9_-]/g, "_")
    : id;
  return `playit_${serverName}`;
}

router.get("/:id/playit", async (req, res) => {
  try {
    const user = (req as any).user;
    if (user.role !== "admin" && user.role !== "owner") {
      return res.status(403).json({ error: "Forbidden" });
    }

    const { id } = req.params;
    const server = await getServerById(id);
    const pm2Name = getPlayitName(server, id);

    const { exec } = await import("child_process");

    exec("npx pm2 jlist", (_err, stdout) => {
      let status = "stopped";
      try {
        const jsonStart = stdout.indexOf("[");
        const jsonEnd = stdout.lastIndexOf("]");
        const jsonStr =
          jsonStart !== -1 && jsonEnd !== -1
            ? stdout.substring(jsonStart, jsonEnd + 1)
            : stdout;
        const pm2List = JSON.parse(jsonStr);
        const proc = pm2List.find((p: any) => p.name === pm2Name);
        if (proc && proc.pm2_env && proc.pm2_env.status === "online") {
          status = "running";
        }
      } catch {
        /* ignore */
      }

      if (status === "running") {
        exec(
          `npx pm2 logs ${pm2Name} --nostream --lines 100`,
          (_err2, logStdout) => {
            const logs = (logStdout || "").replace(
              /\x1b\[[0-9;]*[a-zA-Z]|\x1b./g,
              ""
            );
            const claimLinkMatches = logs.match(
              /https:\/\/playit\.gg\/claim\/[a-zA-Z0-9]+/g
            );
            res.json({
              status,
              claimLink: claimLinkMatches
                ? claimLinkMatches[claimLinkMatches.length - 1]
                : null,
              logs: logs.split("\n").slice(-50).join("\n"),
            });
          }
        );
      } else {
        res.json({ status: "stopped", claimLink: null, logs: "" });
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/:id/playit/start", async (req, res) => {
  try {
    const user = (req as any).user;
    if (user.role !== "admin" && user.role !== "owner") {
      return res.status(403).json({ error: "Forbidden" });
    }

    const { id } = req.params;
    const server = await getServerById(id);
    const pm2Name = getPlayitName(server, id);

    const serverDir = path.join(process.cwd(), ".data", "servers", id);
    const playitBin = path.join(serverDir, pm2Name);
    const secretPath = path.join(serverDir, "playit.toml");

    const { exec } = await import("child_process");

    const setupCmd = `mkdir -p "${serverDir}"; if [ ! -f "${playitBin}" ]; then wget -qO "${playitBin}" "https://github.com/playit-cloud/playit-agent/releases/download/v0.15.26/playit-linux-amd64" && chmod +x "${playitBin}"; fi`;

    exec(
      `npx pm2 delete ${pm2Name} || true; npx pm2 flush ${pm2Name} || true; ${setupCmd} && npx pm2 start "${playitBin}" --name ${pm2Name} -- -s --secret_path "${secretPath}" && npx pm2 save`,
      (err, _stdout, stderr) => {
        if (err) {
          return res
            .status(500)
            .json({ error: "Failed to start Playit Tunnel", details: stderr });
        }
        res.json({ success: true });
      }
    );
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/:id/playit/stop", async (req, res) => {
  try {
    const user = (req as any).user;
    if (user.role !== "admin" && user.role !== "owner") {
      return res.status(403).json({ error: "Forbidden" });
    }

    const { id } = req.params;
    const server = await getServerById(id);
    const pm2Name = getPlayitName(server, id);

    const { exec } = await import("child_process");
    exec(`npx pm2 delete ${pm2Name} && npx pm2 save`, () => {
      res.json({ success: true });
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/:id/playit/reset", async (req, res) => {
  try {
    const user = (req as any).user;
    if (user.role !== "admin" && user.role !== "owner") {
      return res.status(403).json({ error: "Forbidden" });
    }

    const { id } = req.params;
    const server = await getServerById(id);
    const pm2Name = getPlayitName(server, id);
    const serverDir = path.join(process.cwd(), ".data", "servers", id);
    const secretPath = path.join(serverDir, "playit.toml");

    const { exec } = await import("child_process");
    exec(
      `npx pm2 delete ${pm2Name} || true; npx pm2 flush ${pm2Name} || true; rm -f "${secretPath}" && npx pm2 save`,
      () => {
        res.json({ success: true });
      }
    );
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ═════════════════════════════════════════════
//  SUB-USERS
// ═════════════════════════════════════════════
router.get("/:id/subusers", async (req, res) => {
  try {
    const { id } = req.params;
    const reqUser = (req as any).user;

    const servers = (await readJSON(SERVERS_FILE)) || [];
    const server = servers.find((s: any) => s.id === id);
    if (!server) return res.status(404).json({ error: "Server not found" });
    if (!canManageServer(reqUser, server)) {
      return res.status(403).json({ error: "Forbidden" });
    }

    const users = (await readJSON(USERS_FILE)) || [];
    res.json({
      subUsers: server.subUsers || [],
      availableUsers: users.map((u: any) => ({ id: u.id, username: u.username })),
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/:id/subusers", async (req, res) => {
  try {
    const { id } = req.params;
    const reqUser = (req as any).user;
    const { userId, permissions } = req.body;

    const servers = (await readJSON(SERVERS_FILE)) || [];
    const idx = servers.findIndex((s: any) => s.id === id);
    if (idx === -1) return res.status(404).json({ error: "Server not found" });
    if (!canManageServer(reqUser, servers[idx])) {
      return res.status(403).json({ error: "Forbidden" });
    }

    if (!servers[idx].subUsers) servers[idx].subUsers = [];
    const suIdx = servers[idx].subUsers.findIndex((su: any) => su.userId === userId);

    if (suIdx !== -1) {
      servers[idx].subUsers[suIdx].permissions = permissions;
    } else {
      servers[idx].subUsers.push({ userId, permissions });
    }

    await writeJSON(SERVERS_FILE, servers);
    res.json({ success: true, subUsers: servers[idx].subUsers });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.delete("/:id/subusers/:userId", async (req, res) => {
  try {
    const { id, userId } = req.params;
    const reqUser = (req as any).user;

    const servers = (await readJSON(SERVERS_FILE)) || [];
    const idx = servers.findIndex((s: any) => s.id === id);
    if (idx === -1) return res.status(404).json({ error: "Server not found" });
    if (!canManageServer(reqUser, servers[idx])) {
      return res.status(403).json({ error: "Forbidden" });
    }

    if (!servers[idx].subUsers) servers[idx].subUsers = [];
    servers[idx].subUsers = servers[idx].subUsers.filter(
      (su: any) => su.userId !== userId
    );

    await writeJSON(SERVERS_FILE, servers);
    res.json({ success: true, subUsers: servers[idx].subUsers });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ═════════════════════════════════════════════
//  SFTP
// ═════════════════════════════════════════════
router.get("/:id/sftp", async (req, res) => {
  try {
    const { id } = req.params;
    const reqUser = (req as any).user;

    const server = await getServerById(id);
    if (!server) return res.status(404).json({ error: "Server not found" });
    if (!canManageServer(reqUser, server)) {
      return res.status(403).json({ error: "Forbidden" });
    }

    const user = await getSftpUser(id);
    if (!user) return res.status(404).json({ error: "SFTP user not found" });

    res.json({
      host: req.headers.host?.split(":")[0] || "127.0.0.1",
      port: 6868,
      username: user.username,
      password: "(Hidden - Reset to reveal)",
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/:id/sftp/create", async (req, res) => {
  try {
    const { id } = req.params;
    const reqUser = (req as any).user;

    const server = await getServerById(id);
    if (!server) return res.status(404).json({ error: "Server not found" });
    if (!canManageServer(reqUser, server)) {
      return res.status(403).json({ error: "Forbidden" });
    }

    const creds = await createSftpUser(id);
    res.json({
      host: req.headers.host?.split(":")[0] || "127.0.0.1",
      port: 6868,
      username: creds.username,
      password: creds.password,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/:id/sftp/reset-password", async (req, res) => {
  try {
    const { id } = req.params;
    const reqUser = (req as any).user;

    const server = await getServerById(id);
    if (!server) return res.status(404).json({ error: "Server not found" });
    if (!canManageServer(reqUser, server)) {
      return res.status(403).json({ error: "Forbidden" });
    }

    const creds = await resetSftpPassword(id);
    res.json({
      host: req.headers.host?.split(":")[0] || "127.0.0.1",
      port: 6868,
      username: creds.username,
      password: creds.password,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.delete("/:id/sftp", async (req, res) => {
  try {
    const { id } = req.params;
    const reqUser = (req as any).user;

    const server = await getServerById(id);
    if (!server) return res.status(404).json({ error: "Server not found" });
    if (!canManageServer(reqUser, server)) {
      return res.status(403).json({ error: "Forbidden" });
    }

    await deleteSftpUser(id);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ═════════════════════════════════════════════
//  PLUGINS & MODS
// ═════════════════════════════════════════════
router.post("/:id/plugins/install", installPlugin);
router.get("/:id/plugins/installed", getInstalledPlugins);
router.delete("/:id/plugins/:filename", deleteInstalledPlugin);

router.post("/:id/mods/install", installMod);
router.get("/:id/mods/installed", getInstalledMods);
router.delete("/:id/mods/:filename", deleteInstalledMod);

router.get("/:id/modrinth/versions/:projectId", getModrinthProjectVersions);

export default router;