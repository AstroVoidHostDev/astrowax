// ============================================
// AstroWax Panel V1.80 — Device Performance Detector
// Auto-detects low-end devices and disables heavy effects
// ============================================

/**
 * Detect if the current device is low-end / slow
 * Use this to disable video backgrounds, GSAP animations, and heavy blurs
 */
export function isLowEndDevice(): boolean {
  if (typeof window === "undefined") return false;

  // 1. Respect user's reduced-motion preference
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    return true;
  }

  // 2. Hardware concurrency (CPU cores) — <= 4 cores = likely low-end
  const cores = navigator.hardwareConcurrency || 2;
  if (cores <= 4) return true;

  // 3. Device memory (GB) — <= 2GB = low-end
  const memory = (navigator as any).deviceMemory;
  if (memory && memory <= 2) return true;

  // 4. Small screen + old UA hints (mobile)
  const ua = navigator.userAgent;
  const isOldMobile = /Android [4-9]|Android 10/.test(ua) || /iPhone OS [4-9]_|iPhone OS 1[0-2]_/.test(ua);
  if (isOldMobile) return true;

  // 5. Slow network
  const conn = (navigator as any).connection;
  if (conn) {
    const type = conn.effectiveType;
    if (type === "slow-2g" || type === "2g" || type === "3g") return true;
    if (conn.saveData === true) return true;
  }

  return false;
}

/**
 * Returns the right CSS filter value based on device
 * Low-end → no blur (or minimal)
 */
export function getSafeBlur(defaultBlur: number = 20): string {
  return isLowEndDevice() ? `blur(${Math.min(defaultBlur, 8)}px)` : `blur(${defaultBlur}px)`;
}

/**
 * Returns whether we should autoplay video backgrounds
 */
export function shouldUseVideoBackground(): boolean {
  return !isLowEndDevice();
}