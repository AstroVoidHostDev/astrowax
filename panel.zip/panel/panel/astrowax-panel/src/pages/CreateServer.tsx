// @ts-nocheck
import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useSettings } from "../context/SettingsContext";
import axios from "axios";
import CategorizedVersionDropdown from "../components/CategorizedVersionDropdown";
import { getJavaVersionForMinecraft } from "../utils/minecraftJava";
import {
  ArrowLeft, Server, AlertTriangle, AlignLeft, MemoryStick as MemoryStickIcon,
  Cpu, Zap, Sparkles, HardDrive, Globe, User, Radio, GitBranch, Check,
  ChevronDown, Search, Rocket, SlidersHorizontal, FastForward, Network,
  Wrench, Feather, Info, Code2, TerminalSquare, Lock, Hexagon, Activity,
} from "lucide-react";

// ═══════════════════════════════════════════════════════════════
// SAFE JAVA RESOLVER
// ═══════════════════════════════════════════════════════════════
function safeJavaVersion(version, software) {
  try {
    if (!version || typeof version !== "string") return "17";
    const r = getJavaVersionForMinecraft(version, software);
    if (r === undefined || r === null || r === "") return "17";
    return String(r);
  } catch {
    return "17";
  }
}

// ═══════════════════════════════════════════════════════════════
// ERROR BOUNDARY
// ═══════════════════════════════════════════════════════════════
class DeployErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  componentDidCatch(error, info) {
    console.error("[DeployErrorBoundary]", error, info);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div style={{
          minHeight: "100vh", background: "#05030a", color: "#fff",
          display: "flex", alignItems: "center", justifyContent: "center",
          padding: 24, fontFamily: "monospace",
        }}>
          <div style={{
            maxWidth: 560, border: "1px solid rgba(168,85,247,.4)",
            background: "rgba(20,12,35,.7)", padding: 32, borderRadius: 14,
          }}>
            <div style={{ color: "#a855f7", fontSize: 12, letterSpacing: ".3em", marginBottom: 12 }}>
              DEPLOY ERROR
            </div>
            <h1 style={{ fontSize: 22, margin: "0 0 12px" }}>Something went wrong</h1>
            <p style={{ color: "#a1a1aa", fontSize: 13 }}>
              {this.state.error?.message || "Unknown render error."}
            </p>
            <button
              onClick={() => window.location.reload()}
              style={{
                marginTop: 20, padding: "10px 20px",
                background: "linear-gradient(135deg,#a855f7,#7e22ce)",
                color: "#fff", border: "none", borderRadius: 10,
                cursor: "pointer", fontWeight: 700, letterSpacing: ".15em",
              }}
            >
              RELOAD
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

// ═══════════════════════════════════════════════════════════════
// FALLBACK VERSIONS
// ═══════════════════════════════════════════════════════════════
const FALLBACK_VERSIONS = {
  paper: ["26.3","26.2","26.1","1.21.4","1.21.3","1.21.1","1.21","1.20.6","1.20.4","1.20.2","1.20.1","1.20","1.19.4","1.19.3","1.19.2","1.19","1.18.2","1.18.1","1.18","1.17.1","1.17","1.16.5","1.16.4","1.16.3","1.16.1","1.16","1.15.2","1.15.1","1.15","1.14.4","1.14.3","1.14.2","1.14"],
  spigot: ["1.21.4","1.21.3","1.21.1","1.21","1.20.6","1.20.4","1.20.2","1.20.1","1.20","1.19.4","1.19.3","1.19.2","1.19","1.18.2","1.18.1","1.18","1.17.1","1.17","1.16.5","1.16.4","1.16.3","1.16.1","1.16"],
  fabric: ["1.21.4","1.21.3","1.21.1","1.21","1.20.6","1.20.4","1.20.2","1.20.1","1.20","1.19.4","1.19.3","1.19.2","1.19","1.18.2","1.18.1","1.18","1.17.1","1.17","1.16.5","1.16.4","1.16.3","1.16.1","1.16"],
  forge: ["1.21.4","1.21.3","1.21.1","1.21","1.20.6","1.20.4","1.20.1","1.20","1.19.4","1.19.2","1.19","1.18.2","1.18.1","1.18","1.17.1","1.17","1.16.5","1.16.4","1.16.3","1.16.1"],
  bungeecord: ["1.21","1.20","1.19","1.18","1.17","1.16","1.15","1.14","1.13","1.12","1.11","1.10","1.9","1.8"],
  velocity: ["3.3.0","3.2.0","3.1.0","3.0.0"],
  nodejs: ["22.x","21.x","20.x (LTS)","18.x (LTS)","16.x"],
  python: ["3.13","3.12","3.11","3.10","3.9","3.8"],
};

// ═══════════════════════════════════════════════════════════════
// STYLES (light — no blur, no animation heavy)
// ═══════════════════════════════════════════════════════════════
const pageStyles = `
  .deploy-theme { background: #05030a; color: #fff; font-family: 'IBM Plex Sans', sans-serif; min-height: 100vh; position: relative; overflow-x: hidden; }
  .deploy-theme .font-display { font-family: 'Chakra Petch', sans-serif; }
  .deploy-theme .font-mono { font-family: 'IBM Plex Mono', monospace; }
  .deploy-theme .bg-grid { position: fixed; inset: 0; z-index: 0; pointer-events: none; background-image: linear-gradient(rgba(168,85,247,.06) 1px, transparent 1px), linear-gradient(90deg, rgba(168,85,247,.06) 1px, transparent 1px); background-size: 56px 56px; }
  .deploy-theme .glass-panel { background: rgba(15, 8, 30, 0.92); border: 1px solid rgba(168,85,247,.22); box-shadow: 0 20px 60px -20px rgba(0,0,0,.6); position: relative; border-radius: 14px; overflow: visible; }
  .deploy-theme .glass-panel::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 1px; background: linear-gradient(90deg, transparent, rgba(168,85,247,.5), rgba(255,255,255,.3), rgba(168,85,247,.5), transparent); pointer-events: none; border-radius: 14px 14px 0 0; }
  .deploy-theme .inp { width: 100%; background: rgba(14,8,25,.7); border: 1px solid rgba(168,85,247,.2); padding: .85rem 1rem; color: #fff; outline: none; font-size: .95rem; border-radius: 8px; transition: border-color .15s; }
  .deploy-theme .inp::placeholder { color: #4c4c4c; }
  .deploy-theme .inp:focus { border-color: #a855f7; }
  .deploy-theme .sel-card { position: relative; background: rgba(20,12,35,.7); border: 1px solid rgba(168,85,247,.15); cursor: pointer; overflow: hidden; border-radius: 10px; transition: border-color .15s, transform .15s; }
  .deploy-theme .sel-card:hover { border-color: rgba(168,85,247,.6); }
  .deploy-theme .sel-card.selected { border-color: #a855f7; background: rgba(40,22,70,.85); box-shadow: 0 0 0 2px rgba(168,85,247,.5); }
  .deploy-theme .sel-card .tick { position: absolute; top: 8px; right: 8px; width: 20px; height: 20px; background: linear-gradient(135deg, #a855f7, #7e22ce); color: #fff; display: flex; align-items: center; justify-content: center; opacity: 0; transform: scale(.3); transition: opacity .15s, transform .15s; border-radius: 5px; z-index: 2; }
  .deploy-theme .sel-card.selected .tick { opacity: 1; transform: scale(1); }
  .deploy-theme .soft-card .ic { color: #4c4c4c; transition: color .15s; }
  .deploy-theme .soft-card:hover .ic { color: #c084fc; }
  .deploy-theme .soft-card.selected .ic { color: #a855f7; }
  .deploy-theme .btn-primary { background: linear-gradient(135deg, #a855f7, #7e22ce); color: #fff; border-radius: 10px; }
  .deploy-theme .btn-primary:hover:not(:disabled) { transform: translateY(-1px); }
  .deploy-theme .btn-primary:disabled { opacity: .5; cursor: not-allowed; }
  .deploy-theme .btn-ghost { background: rgba(20,12,35,.5); border: 1px solid rgba(168,85,247,.25); color: #a1a1aa; border-radius: 10px; }
  .deploy-theme .btn-ghost:hover:not(:disabled) { border-color: rgba(168,85,247,.6); color: #fff; }
  .deploy-theme .btn-ghost:disabled { opacity: .3; cursor: not-allowed; }
  .deploy-theme .dot { width: 44px; height: 44px; display: flex; align-items: center; justify-content: center; border: 1px solid rgba(168,85,247,.25); background: rgba(20,12,35,.7); font-size: 13px; color: #4c4c4c; border-radius: 12px; transition: border-color .2s, color .2s; }
  .deploy-theme .dot.active { border-color: #a855f7; color: #a855f7; background: rgba(40,22,70,.8); box-shadow: 0 0 0 2px rgba(168,85,247,.4); }
  .deploy-theme .dot.done { background: linear-gradient(135deg, #a855f7, #7e22ce); color: #fff; border-color: #a855f7; }
  .deploy-theme .conn-fill { height: 100%; background: linear-gradient(90deg, #a855f7, #7e22ce); width: 0; transition: width .4s ease; }
  .deploy-theme .anim-forward, .deploy-theme .anim-back { animation: none; }
  .deploy-theme .pulse-dot { animation: none; }
  .deploy-theme .panel-corner { display: none; }
`;

const RAM = [
  { v: 1, label: "Small Testing Server" }, { v: 2, label: "Small Testing Server" },
  { v: 4, label: "Starter Survival" }, { v: 8, label: "Medium Survival Server" },
  { v: 16, label: "Large Community Server" }, { v: 24, label: "Heavy Modpack Server" },
  { v: 32, label: "High-Traffic Network" }, { v: 48, label: "Enterprise Workload" },
  { v: 64, label: "Extreme Performance" },
];
const CPU_MAP = { 1:100,2:100,4:150,8:200,16:300,24:400,32:500,48:700,64:800 };

const MINECRAFT_SOFTWARE = [
  { id:"paper", name:"Paper", desc:"High Performance", icon: Zap },
  { id:"spigot", name:"Spigot", desc:"Classic Plugins", icon: Wrench },
  { id:"fabric", name:"Fabric", desc:"Lightweight Mods", icon: Feather },
  { id:"forge", name:"Forge", desc:"Classic Modpack", icon: Wrench },
  { id:"bungeecord", name:"BungeeCord", desc:"Classic Proxy", icon: Network },
  { id:"velocity", name:"Velocity", desc:"Next-gen Proxy", icon: FastForward },
];
const APPLICATION_SOFTWARE = [
  { id:"nodejs", name:"Node.js", desc:"JS / TS Runtime & Bots", icon: Code2 },
  { id:"python", name:"Python", desc:"Python 3.x Runtime", icon: TerminalSquare },
];
const SOFTWARE = [...MINECRAFT_SOFTWARE, ...APPLICATION_SOFTWARE];
const STEPS = ["IDENTITY","RESOURCES","ACCESS","SOFTWARE","REVIEW"];

// ═══════════════════════════════════════════════════════════════
// CUSTOM DROPDOWN
// ═══════════════════════════════════════════════════════════════
function CustomDropdown({ value, options, onChange, renderValue, renderOption, placeholder }) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const wrapperRef = useRef(null);

  useEffect(() => {
    function handleClickOutside(event) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const safeOptions = Array.isArray(options) ? options : [];
  const filtered = safeOptions.filter((o) =>
    (o.label || o.name || o.value || o.v || "").toString().toLowerCase().includes(search.toLowerCase())
  );
  const selected = safeOptions.find((o) => (o.value || o.v) === value);

  return (
    <div className="relative" ref={wrapperRef}>
      <button type="button" onClick={() => setOpen(!open)} className="w-full flex items-center justify-between gap-3 inp text-left !py-3">
        <span className="flex items-center gap-3 min-w-0">
          {selected ? renderValue(selected) : <span className="text-[#4c4c4c]">{placeholder}</span>}
        </span>
        <ChevronDown className={`w-4 h-4 text-purple-400 shrink-0 ${open ? "rotate-180" : ""}`} />
      </button>
      {open && (
        <div
          className="absolute z-[100] mt-2 w-full shadow-2xl"
          style={{ background: "rgba(13,8,25,.98)", border: "1px solid rgba(168,85,247,.35)", borderRadius: "10px" }}
        >
          <div className="p-2 border-b border-purple-500/20">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-purple-400/60" />
              <input autoFocus className="w-full bg-black/40 border border-purple-500/25 pl-8 pr-2 py-2 text-sm outline-none text-white rounded" placeholder="Search..." value={search} onChange={e => setSearch(e.target.value)} />
            </div>
          </div>
          <div className="max-h-52 overflow-y-auto p-1">
            {filtered.length > 0 ? filtered.map((o, i) => {
              const val = o.value || o.v;
              const isSel = val === value;
              return <div key={i} onClick={() => { onChange(val); setOpen(false); setSearch(""); }}>{renderOption(o, isSel)}</div>;
            }) : <p className="px-3 py-3 text-[11px] text-[#4c4c4c] font-mono">NO RESULTS</p>}
          </div>
        </div>
      )}
    </div>
  );
}

const getInitials = (name) => (name ? name.slice(0, 2).toUpperCase() : "??");

// ═══════════════════════════════════════════════════════════════
// MAIN
// ═══════════════════════════════════════════════════════════════
function CreateServerInner() {
  const { defaultRuntime, isDevPanel, panelName } = useSettings();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [nodes, setNodes] = useState([]);
  const [users, setUsers] = useState([]);
  const [versions, setVersions] = useState([]);

  const [currentStep, setCurrentStep] = useState(0);
  const [maxVisited, setMaxVisited] = useState(0);
  const [deployed, setDeployed] = useState(false);
  const [deployProgress, setDeployProgress] = useState(0);
  const [nameError, setNameError] = useState(false);

  const [portStatus, setPortStatus] = useState("idle");
  const portCheckIdRef = useRef(0);

  const [state, setState] = useState({
    name: "", desc: "", ram: 4, cpu: 150, disk: 10, ip: "", port: 25565,
    runtimeType: defaultRuntime || "docker", owner: user?.id || "",
    node: "", software: "paper", version: "26.3", auto: true,
  });

  useEffect(() => {
    if (defaultRuntime) setState(s => ({ ...s, runtimeType: defaultRuntime }));
  }, [defaultRuntime]);

  useEffect(() => {
    if (!isDevPanel && defaultRuntime) setState(s => ({ ...s, runtimeType: defaultRuntime }));
  }, [isDevPanel, defaultRuntime]);

  useEffect(() => {
    if (currentStep < 2) return;
    if (!state.port || state.port <= 0 || state.port > 65535) {
      setPortStatus("invalid"); return;
    }
    const checkId = ++portCheckIdRef.current;
    setPortStatus("checking");
    const timer = setTimeout(() => {
      axios.get(`/api/servers/check-port?port=${state.port}`)
        .then(res => { if (checkId === portCheckIdRef.current) setPortStatus(res.data?.inUse ? "used" : "available"); })
        .catch(() => { if (checkId === portCheckIdRef.current) setPortStatus("error"); });
    }, 400);
    return () => clearTimeout(timer);
  }, [state.port, currentStep]);

  useEffect(() => {
    axios.get("/api/nodes").then(res => {
      const list = Array.isArray(res.data) ? res.data : [];
      setNodes(list);
      if (list.length > 0) setState(s => (s.node ? s : { ...s, node: list[0].id }));
    }).catch(() => {});

    if (user?.role === "admin" || user?.role === "owner") {
      axios.get("/api/auth/users").then(res => setUsers(Array.isArray(res.data) ? res.data : [])).catch(() => {});
    }
  }, []);

  useEffect(() => {
    const sw = state.software;
    const fallback = FALLBACK_VERSIONS[sw] || ["latest"];
    setVersions(fallback);
    setState(s => ({ ...s, version: fallback[0] || "latest" }));

    axios.get(`/api/system/versions?type=${sw}`)
      .then(res => {
        let v = [];
        if (Array.isArray(res.data)) v = res.data;
        else if (Array.isArray(res.data?.versions)) v = res.data.versions;
        v = v.filter(x => typeof x === "string" && x.length > 0);
        if (v.length > 0) {
          setVersions(v);
          setState(s => ({ ...s, version: v[0] }));
        }
      })
      .catch(() => {});
  }, [state.software]);

  const updateState = (key, val) => setState(prev => ({ ...prev, [key]: val }));

  const handleRamClick = (ramVal) => {
    let newCpu = state.cpu;
    if (state.auto) newCpu = CPU_MAP[ramVal] || 100;
    setState(prev => ({ ...prev, ram: ramVal, cpu: newCpu }));
  };

  const handleAutoToggle = () => {
    const nextAuto = !state.auto;
    setState(prev => ({ ...prev, auto: nextAuto, cpu: nextAuto ? (CPU_MAP[prev.ram] || 100) : prev.cpu }));
  };

  const validateStep = async () => {
    if (currentStep === 0 && !state.name.trim()) { setNameError(true); return false; }
    if (currentStep === 2) {
      if (!state.port || state.port <= 0 || state.port > 65535) { alert("Please enter a valid port."); return false; }
      if (portStatus === "used") { alert("Port is already in use."); return false; }
      if (portStatus === "checking") return false;
      if (portStatus === "error") { alert("Could not verify port."); return false; }
    }
    return true;
  };

  const showStep = (n) => {
    setCurrentStep(n);
    setMaxVisited(Math.max(maxVisited, n));
    window.scrollTo({ top: 0, behavior: "auto" });
  };

  const handleNext = async () => {
    const isValid = await validateStep();
    if (!isValid) return;
    if (currentStep < STEPS.length - 1) showStep(currentStep + 1);
    else launch();
  };

  const launch = async () => {
    if (deployed) return;
    setDeployProgress(1);
    const iv = setInterval(() => {
      setDeployProgress(p => Math.min(90, p + Math.random() * 8 + 2));
    }, 280);

    try {
      const payload = {
        name: state.name, description: state.desc, ram: state.ram, cpuLimit: state.cpu,
        diskLimit: state.disk, port: state.port, ipAlias: state.ip, type: state.software,
        version: state.version, ownerId: state.owner || user?.id,
        runtimeType: state.runtimeType, nodeId: state.node,
      };
      await axios.post("/api/servers", payload);
      clearInterval(iv);
      setDeployProgress(100);
      setTimeout(() => setDeployed(true), 500);
      setTimeout(() => navigate("/servers"), 2500);
    } catch (e) {
      clearInterval(iv);
      setDeployProgress(0);
      alert(e.response?.data?.error || "Failed to deploy");
    }
  };

  const renderReviewRow = (k, v) => (
    <div className="flex items-center justify-between gap-4 px-4 py-3">
      <span className="text-purple-400/60 tracking-widest text-[11px] font-mono uppercase">{k}</span>
      <span className="text-white text-right truncate font-mono">{v}</span>
    </div>
  );

  const isMinecraftSoftware = !["nodejs", "python"].includes(state.software);

  return (
    <div className="deploy-theme">
      <style dangerouslySetInnerHTML={{ __html: pageStyles }} />
      <div className="bg-grid" />

      <div className="relative z-10">
        <nav className="sticky top-0 z-50 border-b border-purple-500/15 bg-black/70">
          <div className="max-w-3xl mx-auto px-5 h-16 flex items-center justify-between">
            <button onClick={() => navigate("/servers")} className="flex items-center gap-2 font-mono text-[11px] tracking-widest text-zinc-400 border border-purple-500/20 px-3 py-1.5 rounded-lg">
              <ArrowLeft className="w-3.5 h-3.5" /> INSTANCES
            </button>
            <a href="#" onClick={(e) => { e.preventDefault(); navigate("/servers"); }} className="flex items-center gap-3">
              <span className="font-display font-bold text-lg text-white">{panelName || "AstroWax Panel"}</span>
              <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-purple-700 flex items-center justify-center rounded-lg">
                <Hexagon className="w-4 h-4 text-white" />
              </div>
            </a>
          </div>
        </nav>

        <main className="max-w-3xl mx-auto px-5 pt-12 pb-16">
          <header className="mb-10">
            <p className="font-mono text-[11px] tracking-[0.3em] text-purple-400/80 mb-3 flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-purple-500 rounded-full"></span> NEW CONTAINER
            </p>
            <h1 className="font-display font-bold tracking-tight text-4xl md:text-5xl text-white">
              DEPLOY <span className="bg-gradient-to-r from-purple-400 via-purple-300 to-purple-500 bg-clip-text text-transparent">INSTANCE</span>
            </h1>
          </header>

          {/* Stepper */}
          <div className="mb-4">
            <div className="flex items-start">
              {STEPS.map((s, i) => (
                <div key={i} className="contents">
                  <div className="flex flex-col items-center flex-shrink-0" style={{ width: "56px" }}>
                    <button
                      type="button"
                      onClick={() => { if (i <= maxVisited && i !== currentStep && !deployed) showStep(i); }}
                      className={`dot font-mono ${i < currentStep ? "done" : i === currentStep ? "active" : ""}`}
                    >
                      {i < currentStep ? <Check className="w-4 h-4" /> : String(i + 1).padStart(2, "0")}
                    </button>
                    <span className="hidden sm:block mt-2 font-mono text-[9px] tracking-widest text-center text-purple-400/60">{s}</span>
                  </div>
                  {i < STEPS.length - 1 && (
                    <div className="flex-1 h-px bg-purple-500/20 mt-[22px] mx-1 relative">
                      <div className="conn-fill absolute inset-0" style={{ width: i < currentStep ? "100%" : "0%" }}></div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="glass-panel p-6 md:p-9 mt-6">
            {/* STEP 1 */}
            {currentStep === 0 && (
              <div>
                <div className="flex items-center gap-3 mb-6">
                  <span className="font-mono text-xs text-purple-500 bg-purple-500/10 border border-purple-500/30 px-2 py-0.5 rounded">01</span>
                  <h2 className="font-display font-bold tracking-wide text-sm text-white">IDENTITY</h2>
                  <span className="flex-1 h-px bg-gradient-to-r from-purple-500/30 to-transparent"></span>
                </div>

                <label className="flex items-center gap-2 text-sm text-zinc-400 mb-2.5">
                  <Server className="w-4 h-4 text-purple-400" /> Instance Name <span className="text-purple-400">*</span>
                </label>
                <input
                  type="text"
                  className={`inp ${nameError ? "!border-red-500/60" : ""}`}
                  placeholder="e.g. Production Survival"
                  value={state.name}
                  onChange={(e) => { updateState("name", e.target.value); setNameError(false); }}
                />
                {nameError && <p className="mt-2 text-xs text-red-400 font-mono">Instance name required.</p>}

                <label className="flex items-center gap-2 text-sm text-zinc-400 mb-2.5 mt-7">
                  <AlignLeft className="w-4 h-4 text-purple-400" /> Description
                </label>
                <textarea
                  className="inp"
                  style={{ resize: "vertical", minHeight: "96px" }}
                  placeholder="Optional description"
                  value={state.desc}
                  onChange={(e) => updateState("desc", e.target.value)}
                />

                <div className="mt-7 p-3 rounded-lg bg-purple-500/5 border border-purple-500/20 text-[11px] text-zinc-400 flex items-start gap-2.5 font-mono">
                  <Info className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
                  <span>Runtime: <strong className="text-purple-300 uppercase">{state.runtimeType}</strong> (managed by admin)</span>
                </div>
              </div>
            )}

            {/* STEP 2 */}
            {currentStep === 1 && (
              <div>
                <div className="flex items-center gap-3 mb-6">
                  <span className="font-mono text-xs text-purple-500 bg-purple-500/10 border border-purple-500/30 px-2 py-0.5 rounded">02</span>
                  <h2 className="font-display font-bold tracking-wide text-sm text-white">RESOURCES</h2>
                  <span className="flex-1 h-px bg-gradient-to-r from-purple-500/30 to-transparent"></span>
                </div>

                <label className="flex items-center gap-2 text-sm text-zinc-400 mb-4">
                  <MemoryStickIcon className="w-4 h-4 text-purple-400" /> RAM Allocation (GB)
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {RAM.map(r => (
                    <button
                      key={r.v}
                      type="button"
                      onClick={() => handleRamClick(r.v)}
                      className={`sel-card p-4 text-left ${r.v === state.ram ? "selected" : ""}`}
                    >
                      <span className="tick"><Check className="w-3 h-3" /></span>
                      <div className="font-display font-bold text-2xl text-white">
                        {r.v}<span className="text-sm text-zinc-500 ml-1">GB</span>
                      </div>
                      <div className="text-[11px] text-zinc-500 mt-1.5">{r.label}</div>
                    </button>
                  ))}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mt-8">
                  <div>
                    <label className="flex items-center gap-2 text-sm text-zinc-400 mb-2.5">
                      <Cpu className="w-4 h-4 text-purple-400" /> CPU Limit (%)
                    </label>
                    <div className="flex gap-2.5">
                      <input
                        type="number" min="10"
                        className="inp font-mono flex-1"
                        value={state.cpu}
                        onChange={(e) => { updateState("cpu", Number(e.target.value)); updateState("auto", false); }}
                      />
                      <button
                        type="button"
                        onClick={handleAutoToggle}
                        className={`px-4 py-3 font-display font-bold text-sm border rounded-lg ${state.auto ? "bg-purple-600 text-white border-purple-400" : "bg-transparent text-zinc-400 border-purple-500/25"}`}
                      >
                        {state.auto ? "AUTO" : "MANUAL"}
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="flex items-center gap-2 text-sm text-zinc-400 mb-2.5">
                      <HardDrive className="w-4 h-4 text-purple-400" /> Disk Limit (GB)
                    </label>
                    <input
                      type="number" min="1"
                      className="inp font-mono"
                      value={state.disk}
                      onChange={(e) => updateState("disk", Number(e.target.value))}
                    />
                  </div>
                </div>
              </div>
            )}

            {/* STEP 3 */}
            {currentStep === 2 && (
              <div>
                <div className="flex items-center gap-3 mb-6">
                  <span className="font-mono text-xs text-purple-500 bg-purple-500/10 border border-purple-500/30 px-2 py-0.5 rounded">03</span>
                  <h2 className="font-display font-bold tracking-wide text-sm text-white">NETWORK & ACCESS</h2>
                  <span className="flex-1 h-px bg-gradient-to-r from-purple-500/30 to-transparent"></span>
                </div>

                <label className="flex items-center gap-2 text-sm text-zinc-400 mb-2.5">
                  <Network className="w-4 h-4 text-purple-400" /> Server Port
                </label>
                <div className="relative mb-4">
                  <input
                    type="number"
                    className={`inp font-mono ${portStatus === "used" || portStatus === "invalid" ? "!border-red-500/60" : portStatus === "available" ? "!border-emerald-500/60" : ""}`}
                    placeholder="25565"
                    value={state.port || ""}
                    onChange={e => updateState("port", e.target.value ? Number(e.target.value) : "")}
                  />
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 font-mono text-[10px]">
                    {portStatus === "checking" && <span className="text-purple-400">CHECKING...</span>}
                    {portStatus === "available" && <span className="text-emerald-400">AVAILABLE</span>}
                    {portStatus === "used" && <span className="text-red-400">IN USE</span>}
                    {portStatus === "invalid" && <span className="text-red-400">INVALID</span>}
                    {portStatus === "error" && <span className="text-red-400">ERROR</span>}
                  </div>
                </div>

                <label className="flex items-center gap-2 text-sm text-zinc-400 mb-2.5 mt-7">
                  <Globe className="w-4 h-4 text-purple-400" /> IP Alias
                </label>
                <input
                  type="text" className="inp font-mono" placeholder="play.example.com"
                  value={state.ip} onChange={e => updateState("ip", e.target.value)}
                />

                {(user?.role === "admin" || user?.role === "owner") && (
                  <>
                    <label className="flex items-center gap-2 text-sm text-zinc-400 mb-2.5 mt-7">
                      <User className="w-4 h-4 text-purple-400" /> Assign Server Owner
                    </label>
                    <CustomDropdown
                      value={state.owner}
                      options={users.map(u => ({ v: u.id, name: u.username, tag: u.role, role: u.role }))}
                      onChange={(v) => updateState("owner", v)}
                      placeholder="Select owner..."
                      renderValue={(o) => (
                        <>
                          <span className="w-8 h-8 rounded-lg border border-purple-500/30 bg-purple-600/20 flex items-center justify-center text-xs text-purple-200 shrink-0">
                            {getInitials(o.name)}
                          </span>
                          <span className="truncate text-white font-mono text-sm">{o.name} <span className="text-zinc-500">({o.tag})</span></span>
                        </>
                      )}
                      renderOption={(o, sel) => (
                        <button type="button" className={`w-full flex items-center gap-3 px-3 py-2.5 rounded ${sel ? "bg-purple-500/15" : "hover:bg-purple-500/8"}`}>
                          <span className="w-8 h-8 rounded-lg border border-purple-500/30 bg-purple-600/20 flex items-center justify-center text-xs text-purple-200">{getInitials(o.name)}</span>
                          <span className="flex-1 text-left font-mono text-sm text-white">{o.name} <span className="text-zinc-500">({o.tag})</span></span>
                          {sel && <Check className="w-4 h-4 text-purple-400" />}
                        </button>
                      )}
                    />

                    <label className="flex items-center gap-2 text-sm text-zinc-400 mb-2.5 mt-7">
                      <Radio className="w-4 h-4 text-purple-400" /> Deployment Node
                    </label>
                    <CustomDropdown
                      value={state.node}
                      options={nodes.map(n => ({ v: n.id, label: n.name + " (" + n.ip + ")" }))}
                      onChange={(v) => updateState("node", v)}
                      placeholder="Select node..."
                      renderValue={(o) => (
                        <>
                          <Radio className="w-4 h-4 text-purple-400 shrink-0" />
                          <span className="text-white truncate font-mono text-sm">{o.label}</span>
                        </>
                      )}
                      renderOption={(o, sel) => (
                        <button type="button" className={`w-full flex items-center justify-between px-3 py-2.5 font-mono text-sm rounded ${sel ? "text-white bg-purple-500/15" : "text-zinc-400 hover:bg-purple-500/8"}`}>
                          <span>{o.label}</span>
                          {sel && <Check className="w-4 h-4 text-purple-400" />}
                        </button>
                      )}
                    />
                  </>
                )}
              </div>
            )}

            {/* STEP 4 */}
            {currentStep === 3 && (
              <div className="space-y-6">
                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <span className="font-mono text-xs text-purple-500 bg-purple-500/10 border border-purple-500/30 px-2 py-0.5 rounded">04A</span>
                    <h2 className="font-display font-bold tracking-wide text-sm text-white">MINECRAFT ENGINES</h2>
                    <span className="flex-1 h-px bg-gradient-to-r from-purple-500/30 to-transparent"></span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                    {MINECRAFT_SOFTWARE.map(s => {
                      const Icon = s.icon;
                      return (
                        <button
                          key={s.id}
                          type="button"
                          onClick={() => updateState("software", s.id)}
                          className={`sel-card soft-card p-4 flex flex-col items-center text-center ${state.software === s.id ? "selected" : ""}`}
                        >
                          <span className="tick"><Check className="w-3 h-3" /></span>
                          <Icon className="ic w-6 h-6 mb-2.5" />
                          <span className="font-display font-semibold text-sm text-white">{s.name}</span>
                          <span className="text-[10px] text-zinc-500 mt-1">{s.desc}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <span className="font-mono text-xs text-purple-500 bg-purple-500/10 border border-purple-500/30 px-2 py-0.5 rounded">04B</span>
                    <h2 className="font-display font-bold tracking-wide text-sm text-white">APPLICATION RUNTIMES</h2>
                    <span className="flex-1 h-px bg-gradient-to-r from-purple-500/30 to-transparent"></span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {APPLICATION_SOFTWARE.map(s => {
                      const Icon = s.icon;
                      return (
                        <button
                          key={s.id}
                          type="button"
                          onClick={() => updateState("software", s.id)}
                          className={`sel-card soft-card p-4 flex items-center gap-4 text-left ${state.software === s.id ? "selected" : ""}`}
                        >
                          <span className="tick"><Check className="w-3 h-3" /></span>
                          <div className="w-10 h-10 rounded-lg bg-purple-500/10 border border-purple-500/25 flex items-center justify-center">
                            <Icon className="ic w-5 h-5 text-purple-300" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="font-display font-semibold text-sm text-white">{s.name}</div>
                            <span className="text-[11px] text-zinc-500">{s.desc}</span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <label className="flex items-center gap-2 text-sm text-zinc-400 mb-2.5">
                    <GitBranch className="w-4 h-4 text-purple-400" /> {isMinecraftSoftware ? "Software Version" : "Runtime Version"}
                  </label>

                  <CategorizedVersionDropdown
                    value={state.version}
                    onChange={(v) => updateState("version", v)}
                    versions={versions}
                    software={state.software}
                    placeholder="Select a version..."
                  />
                  {isMinecraftSoftware && (
                    <div className="mt-2.5 flex items-center gap-1.5 text-xs text-emerald-400 font-mono">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Java {safeJavaVersion(state.version, state.software)} auto-provisioned</span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* STEP 5 */}
            {currentStep === 4 && (
              <div>
                <div className="flex items-center gap-3 mb-6">
                  <span className="font-mono text-xs text-purple-500 bg-purple-500/10 border border-purple-500/30 px-2 py-0.5 rounded">05</span>
                  <h2 className="font-display font-bold tracking-wide text-sm text-white">FINAL SPECIFICATION</h2>
                  <span className="flex-1 h-px bg-gradient-to-r from-purple-500/30 to-transparent"></span>
                </div>

                {!deployed && deployProgress === 0 && (
                  <div className="font-mono text-[13px] divide-y divide-purple-500/15 border border-purple-500/25 bg-black/40 rounded-lg">
                    {renderReviewRow("INSTANCE", state.name || "—")}
                    {renderReviewRow("RUNTIME", state.runtimeType === "local" ? "Local Process" : "Docker")}
                    {renderReviewRow("DESCRIPTION", state.desc || "—")}
                    {renderReviewRow("PORT", String(state.port))}
                    {renderReviewRow("RAM", state.ram + " GB")}
                    {renderReviewRow("CPU " + (state.auto ? "(AUTO)" : "(MANUAL)"), state.cpu + " %")}
                    {renderReviewRow("DISK", state.disk + " GB")}
                    {renderReviewRow("IP ALIAS", state.ip || "—")}
                    {renderReviewRow("SOFTWARE", SOFTWARE.find(s => s.id === state.software)?.name || "Unknown")}
                    {renderReviewRow("VERSION", state.version || "latest")}
                    {isMinecraftSoftware && renderReviewRow("JAVA RUNTIME", `Java ${safeJavaVersion(state.version, state.software)}`)}
                  </div>
                )}

                {deployProgress > 0 && !deployed && (
                  <div className="mt-6 border border-purple-500/30 bg-black/40 p-4 rounded-lg">
                    <div className="flex justify-between mb-2.5">
                      <span className="text-sm font-mono text-zinc-400">Provisioning...</span>
                      <span className="text-sm font-mono text-purple-300">{Math.round(deployProgress)}%</span>
                    </div>
                    <div className="w-full bg-black/60 h-2 overflow-hidden rounded-full">
                      <div className="h-full bg-gradient-to-r from-purple-600 to-purple-400" style={{ width: `${deployProgress}%` }} />
                    </div>
                  </div>
                )}

                {deployed && (
                  <div className="mt-6 border-2 border-purple-500/60 bg-purple-600/20 p-6 text-center rounded-xl">
                    <div className="w-14 h-14 mx-auto mb-3 bg-purple-600 text-white flex items-center justify-center rounded-xl">
                      <Check className="w-7 h-7" />
                    </div>
                    <p className="font-display font-bold text-lg">Instance Deployed</p>
                    <p className="text-purple-300 text-sm mt-1 font-mono">{state.name} → {state.ram}GB</p>
                  </div>
                )}
              </div>
            )}

            {/* NAV */}
            <div className="flex items-center justify-between gap-3 mt-9 pt-7 border-t border-purple-500/20">
              <button
                type="button"
                onClick={() => { if (currentStep > 0) showStep(currentStep - 1); }}
                disabled={currentStep === 0 || deployed || deployProgress > 0}
                className="btn-ghost px-5 py-3 text-sm font-medium flex items-center gap-2"
              >
                <ArrowLeft className="w-4 h-4" /> BACK
              </button>

              <span className="font-mono text-[11px] text-purple-400/60 hidden sm:block">
                STEP {currentStep + 1} / {STEPS.length}
              </span>

              <button
                type="button"
                onClick={handleNext}
                disabled={deployed || deployProgress > 0}
                className="btn-primary px-7 py-3 text-sm font-display font-bold tracking-widest flex items-center gap-2"
              >
                {currentStep === STEPS.length - 1 ? (deployed ? "DEPLOYED" : "LAUNCH") : "NEXT"}
                {currentStep === STEPS.length - 1 ? <Rocket className="w-4 h-4" /> : <ArrowLeft className="w-4 h-4 rotate-180" />}
              </button>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

export default function CreateServer() {
  return (
    <DeployErrorBoundary>
      <CreateServerInner />
    </DeployErrorBoundary>
  );
}