// @ts-nocheck
import PageHeader from "../components/PageHeader";
import React, { useState, useEffect, useMemo, useCallback } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import {
  Server, Settings, Search, Trash2, Edit2, Play, Square,
  PauseCircle, MoreVertical, ChevronRight, Hexagon,
  Sparkles, AlertTriangle, CheckCircle2, Shield, Filter,
  ArrowUpDown, RefreshCw, Power, Users, X, Lock, Activity
} from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { motion, AnimatePresence } from "framer-motion";

// ============================================
// AstroWax Panel V1.80 — Admin Servers (Enhanced)
// Glass + Purple Theme + Full Role Guard
// ============================================

type SortKey = "name" | "status" | "ram" | "owner";
type FilterKey = "all" | "online" | "offline" | "suspended";

export default function AdminServers() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [servers, setServers] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortKey, setSortKey] = useState<SortKey>("name");
  const [sortAsc, setSortAsc] = useState(true);
  const [filterKey, setFilterKey] = useState<FilterKey>("all");
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  const [editingServer, setEditingServer] = useState<any>(null);
  const [ram, setRam] = useState("");
  const [cpu, setCpu] = useState("");
  const [disk, setDisk] = useState("");

  const [suspendingServer, setSuspendingServer] = useState<any>(null);
  const [suspendDuration, setSuspendDuration] = useState("null");

  const [deletingServer, setDeletingServer] = useState<any>(null);
  const [bulkDelete, setBulkDelete] = useState(false);

  // ✅ ROLE GUARD — regular users cannot access this page
  const isAdmin = user?.role === "admin" || user?.role === "owner";

  // ═══════════════════════════════════════════════════════════
  // DATA FETCH
  // ═══════════════════════════════════════════════════════════
  const fetchData = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    else setRefreshing(true);
    try {
      const [serversRes, usersRes] = await Promise.all([
        axios.get("/api/servers"),
        axios.get("/api/system/users"),
      ]);
      setServers(Array.isArray(serversRes.data) ? serversRes.data : []);
      setUsers(Array.isArray(usersRes.data) ? usersRes.data : []);
    } catch (e: any) {
      console.error("fetchData error:", e);
      if (!silent) {
        alert("Failed to load data: " + (e.response?.data?.error || e.message));
      }
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    if (isAdmin) fetchData();
  }, [isAdmin, fetchData]);

  // ═══════════════════════════════════════════════════════════
  // ESC to close modals
  // ═══════════════════════════════════════════════════════════
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return;
      if (editingServer) setEditingServer(null);
      else if (suspendingServer) setSuspendingServer(null);
      else if (deletingServer) setDeletingServer(null);
      else if (bulkDelete) setBulkDelete(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [editingServer, suspendingServer, deletingServer, bulkDelete]);

  // ═══════════════════════════════════════════════════════════
  // HELPERS
  // ═══════════════════════════════════════════════════════════
  const getUsername = useCallback(
    (id: string) => {
      if (!id) return "Unknown";
      const u = users.find((u) => u.id === id);
      return u ? u.username : id.slice(0, 8);
    },
    [users]
  );

  const getStatus = (server: any): "online" | "offline" | "suspended" => {
    if (server.suspended) return "suspended";
    return server.status === "online" ? "online" : "offline";
  };

  // ═══════════════════════════════════════════════════════════
  // FILTER + SORT + SEARCH
  // ═══════════════════════════════════════════════════════════
  const filteredServers = useMemo(() => {
    let list = servers;

    // Filter
    if (filterKey !== "all") {
      list = list.filter((s) => getStatus(s) === filterKey);
    }

    // Search
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      list = list.filter(
        (s) =>
          s.name?.toLowerCase().includes(q) ||
          s.id?.toLowerCase().includes(q) ||
          s.type?.toLowerCase().includes(q) ||
          s.version?.toLowerCase().includes(q) ||
          getUsername(s.owner)?.toLowerCase().includes(q)
      );
    }

    // Sort
    const sorted = [...list].sort((a, b) => {
      let cmp = 0;
      switch (sortKey) {
        case "name":
          cmp = (a.name || "").localeCompare(b.name || "");
          break;
        case "status":
          cmp = getStatus(a).localeCompare(getStatus(b));
          break;
        case "ram":
          cmp = (Number(a.ram) || 0) - (Number(b.ram) || 0);
          break;
        case "owner":
          cmp = getUsername(a.owner).localeCompare(getUsername(b.owner));
          break;
      }
      return sortAsc ? cmp : -cmp;
    });

    return sorted;
  }, [servers, filterKey, searchTerm, sortKey, sortAsc, getUsername]);

  // ═══════════════════════════════════════════════════════════
  // BULK SELECTION
  // ═══════════════════════════════════════════════════════════
  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === filteredServers.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredServers.map((s) => s.id)));
    }
  };

  // ═══════════════════════════════════════════════════════════
  // ACTIONS
  // ═══════════════════════════════════════════════════════════
  const handleUpdateResources = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await axios.put(`/api/servers/${editingServer.id}/resources`, {
        ram: Number(ram),
        cpu: Number(cpu),
        disk: Number(disk),
      });
      setEditingServer(null);
      fetchData(true);
    } catch (e: any) {
      alert("Failed to update resources: " + (e.response?.data?.error || e.message));
    }
  };

  const handleUpdateSuspend = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const duration = suspendDuration === "null" ? null : suspendDuration;
      await axios.put(`/api/servers/${suspendingServer.id}/suspend`, {
        suspendDuration: duration,
      });
      setSuspendingServer(null);
      fetchData(true);
    } catch (e: any) {
      alert("Failed to update suspension: " + (e.response?.data?.error || e.message));
    }
  };

  const handleDelete = async () => {
    try {
      await axios.delete(`/api/servers/${deletingServer.id}`);
      setDeletingServer(null);
      fetchData(true);
    } catch (e: any) {
      alert("Failed to delete server: " + (e.response?.data?.error || e.message));
    }
  };

  const handleBulkDelete = async () => {
    try {
      await Promise.all(
        Array.from(selectedIds).map((id) => axios.delete(`/api/servers/${id}`))
      );
      setSelectedIds(new Set());
      setBulkDelete(false);
      fetchData(true);
    } catch (e: any) {
      alert("Failed to delete some servers: " + (e.response?.data?.error || e.message));
    }
  };

  const handleServerAction = async (id: string, action: "start" | "stop" | "restart") => {
    try {
      await axios.post(`/api/servers/${id}/${action}`);
      fetchData(true);
    } catch (e: any) {
      alert(`Failed to ${action} server: ` + (e.response?.data?.error || e.message));
    }
  };

  // ═══════════════════════════════════════════════════════════
  // GUARD: Non-admin sees warning
  // ═══════════════════════════════════════════════════════════
  if (!isAdmin) {
    return (
      <div className="w-full relative z-10">
        <PageHeader title="Access Denied" subtitle="ADMINISTRATION" />
        <div className="aw-as-glass p-12 text-center max-w-xl mx-auto">
          <div
            className="w-16 h-16 mx-auto mb-4 rounded-2xl flex items-center justify-center"
            style={{
              background: "rgba(244,63,94,.1)",
              border: "1px solid rgba(244,63,94,.35)",
            }}
          >
            <Lock size={28} style={{ color: "#f43f5e" }} />
          </div>
          <h2 className="text-lg font-bold mb-2" style={{ color: "#fda4af" }}>
            Admin Access Required
          </h2>
          <p className="text-sm mb-6" style={{ color: "#a1a1aa" }}>
            You don't have permission to view this page.
          </p>
          <button
            onClick={() => navigate("/")}
            className="aw-as-btn px-5 py-2.5 rounded-xl text-sm font-semibold text-white"
            style={{
              background: "linear-gradient(135deg, #a855f7, #7e22ce)",
              boxShadow: "0 4px 16px -4px rgba(168,85,247,.6)",
            }}
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }

  return (
    <>
      <style dangerouslySetInnerHTML={{__html: `
        .aw-as-glass {
          background: linear-gradient(135deg, rgba(20,12,35,.7) 0%, rgba(13,8,25,.85) 100%);
          backdrop-filter: blur(16px) saturate(1.4);
          -webkit-backdrop-filter: blur(16px) saturate(1.4);
          border: 1px solid rgba(168,85,247,.2);
          border-radius: 16px;
          position: relative;
          overflow: visible;
          transition: all .3s cubic-bezier(.16,1,.3,1);
        }
        .aw-as-glass::before {
          content: '';
          position: absolute;
          top: 0; left: 0; right: 0;
          height: 1px;
          background: linear-gradient(90deg, transparent, rgba(168,85,247,.5), rgba(255,255,255,.2), rgba(168,85,247,.5), transparent);
          pointer-events: none;
          z-index: 2;
          border-radius: 16px 16px 0 0;
        }
        .aw-as-glass:hover { border-color: rgba(168,85,247,.4); }
        .aw-as-row { transition: all .25s cubic-bezier(.16,1,.3,1); }
        .aw-as-row:hover { background: rgba(168,85,247,.06); }
        .aw-as-btn { transition: all .25s cubic-bezier(.16,1,.3,1); }
        .aw-as-btn:hover:not(:disabled) { transform: translateY(-1px); }
        .aw-as-btn:active:not(:disabled) { transform: translateY(0) scale(.97); }
        .aw-as-scroll::-webkit-scrollbar { width: 8px; height: 8px; }
        .aw-as-scroll::-webkit-scrollbar-track { background: rgba(0,0,0,.3); }
        .aw-as-scroll::-webkit-scrollbar-thumb {
          background: linear-gradient(180deg, #a855f7, #7e22ce);
          border-radius: 4px;
        }
        .aw-as-input { transition: all .25s cubic-bezier(.16,1,.3,1); }
        .aw-as-input:focus {
          outline: none;
          border-color: rgba(168,85,247,.6) !important;
          box-shadow: 0 0 0 3px rgba(168,85,247,.1), 0 0 20px -4px rgba(168,85,247,.4) !important;
        }
        .aw-as-input::placeholder { color: rgba(161,161,170,.5); }
        .aw-as-modal {
          background: linear-gradient(135deg, rgba(20,12,35,.96), rgba(13,8,25,.98));
          border: 1px solid rgba(168,85,247,.35);
          backdrop-filter: blur(24px) saturate(1.4);
          border-radius: 20px;
          position: relative;
          overflow: hidden;
          box-shadow: 0 30px 80px -20px rgba(0,0,0,.9), 0 0 0 1px rgba(168,85,247,.15), 0 0 40px -12px rgba(168,85,247,.4);
        }
        .aw-as-modal::before {
          content: '';
          position: absolute;
          top: 0; left: 0; right: 0;
          height: 1px;
          background: linear-gradient(90deg, transparent, rgba(168,85,247,.6), rgba(255,255,255,.25), rgba(168,85,247,.6), transparent);
        }
        .aw-as-select option { background: #0d0819; color: #e9d5ff; }
        .aw-as-ctx-menu {
          background: linear-gradient(135deg, rgba(20,12,35,.98), rgba(13,8,25,.98));
          border: 1px solid rgba(168,85,247,.35);
          backdrop-filter: blur(20px) saturate(1.4);
          border-radius: 14px;
          overflow: hidden;
          box-shadow: 0 20px 48px -12px rgba(0,0,0,.8), 0 0 0 1px rgba(168,85,247,.15), 0 0 24px -8px rgba(168,85,247,.4);
        }
        @keyframes awAsIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .aw-as-in { animation: awAsIn .4s cubic-bezier(.16,1,.3,1) both; }
        @keyframes awAsSpin { to { transform: rotate(360deg); } }
        .aw-as-spinner {
          border: 2px solid rgba(168,85,247,.2);
          border-top-color: #a855f7;
          border-right-color: #c084fc;
          border-radius: 50%;
          filter: drop-shadow(0 0 8px rgba(168,85,247,.6));
          animation: awAsSpin 1.2s linear infinite;
        }
      `}} />

      <div className="w-full relative z-10">
        <PageHeader
          title="Manage Servers"
          subtitle="ASTROWAX ADMINISTRATION"
          actions={
            <button
              onClick={() => fetchData(true)}
              disabled={refreshing}
              className="aw-as-btn flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold"
              style={{
                background: "rgba(0,0,0,.4)",
                border: "1px solid rgba(168,85,247,.25)",
                color: "#c084fc",
              }}
            >
              <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? "animate-spin" : ""}`} />
              Refresh
            </button>
          }
        />

        {/* Stats Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6 aw-as-in">
          {[
            { label: "Total", value: servers.length, color: "#c084fc", icon: Server },
            {
              label: "Online",
              value: servers.filter((s) => getStatus(s) === "online").length,
              color: "#10b981",
              icon: Activity,
            },
            {
              label: "Offline",
              value: servers.filter((s) => getStatus(s) === "offline").length,
              color: "#71717a",
              icon: Power,
            },
            {
              label: "Suspended",
              value: servers.filter((s) => s.suspended).length,
              color: "#fbbf24",
              icon: PauseCircle,
            },
          ].map((stat, i) => (
            <div key={i} className="aw-as-glass p-4">
              <div className="flex items-center gap-3">
                <div
                  className="w-9 h-9 rounded-lg flex items-center justify-center"
                  style={{
                    background: `${stat.color}15`,
                    border: `1px solid ${stat.color}40`,
                  }}
                >
                  <stat.icon size={16} style={{ color: stat.color }} />
                </div>
                <div>
                  <p className="text-2xl font-bold" style={{ color: "#e9d5ff" }}>
                    {stat.value}
                  </p>
                  <p
                    className="text-[10px] uppercase tracking-widest font-medium"
                    style={{ color: "#a1a1aa" }}
                  >
                    {stat.label}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Controls Bar */}
        <div className="aw-as-glass p-4 mb-6 aw-as-in">
          <div className="flex flex-col md:flex-row gap-3">
            {/* Search */}
            <div className="flex-1 flex items-center">
              <div
                className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0 mr-3"
                style={{
                  background: "rgba(168,85,247,.12)",
                  border: "1px solid rgba(168,85,247,.3)",
                  boxShadow: "0 0 16px -4px rgba(168,85,247,.5)",
                }}
              >
                <Search className="w-4 h-4" style={{ color: "#c084fc" }} />
              </div>
              <input
                type="text"
                placeholder="Search by name, ID, owner, software..."
                className="aw-as-input bg-transparent outline-none flex-1 text-sm"
                style={{ color: "#e9d5ff", caretColor: "#c084fc" }}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              {searchTerm && (
                <button
                  onClick={() => setSearchTerm("")}
                  className="p-1.5 rounded-md"
                  style={{ color: "#c084fc" }}
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Filter pills */}
            <div className="flex items-center gap-1 p-1 rounded-xl"
              style={{
                background: "rgba(0,0,0,.4)",
                border: "1px solid rgba(168,85,247,.2)",
              }}
            >
              {(["all", "online", "offline", "suspended"] as FilterKey[]).map((f) => (
                <button
                  key={f}
                  onClick={() => setFilterKey(f)}
                  className="px-3 py-1.5 rounded-lg text-[11px] font-semibold uppercase tracking-wider aw-as-btn capitalize"
                  style={
                    filterKey === f
                      ? {
                          background: "linear-gradient(135deg, #a855f7, #7e22ce)",
                          color: "#fff",
                          boxShadow: "0 4px 12px -4px rgba(168,85,247,.6)",
                        }
                      : { color: "#a1a1aa" }
                  }
                >
                  {f}
                </button>
              ))}
            </div>

            {/* Sort */}
            <div className="flex items-center gap-1 p-1 rounded-xl"
              style={{
                background: "rgba(0,0,0,.4)",
                border: "1px solid rgba(168,85,247,.2)",
              }}
            >
              <button
                onClick={() => {
                  const keys: SortKey[] = ["name", "status", "ram", "owner"];
                  const idx = keys.indexOf(sortKey);
                  setSortKey(keys[(idx + 1) % keys.length]);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-semibold aw-as-btn"
                style={{ color: "#c084fc" }}
                title="Change sort key"
              >
                <ArrowUpDown className="w-3 h-3" />
                {sortKey}
              </button>
              <button
                onClick={() => setSortAsc(!sortAsc)}
                className="px-2 py-1.5 rounded-lg text-[10px] font-mono aw-as-btn"
                style={{ color: "#c084fc" }}
                title="Toggle direction"
              >
                {sortAsc ? "↑" : "↓"}
              </button>
            </div>
          </div>

          {/* Bulk actions bar */}
          {selectedIds.size > 0 && (
            <div
              className="mt-3 flex items-center justify-between px-3 py-2 rounded-xl"
              style={{
                background: "rgba(168,85,247,.1)",
                border: "1px solid rgba(168,85,247,.3)",
              }}
            >
              <span className="text-xs font-semibold" style={{ color: "#c084fc" }}>
                {selectedIds.size} server{selectedIds.size !== 1 ? "s" : ""} selected
              </span>
              <div className="flex gap-2">
                <button
                  onClick={() => setSelectedIds(new Set())}
                  className="px-3 py-1.5 rounded-lg text-[11px] font-semibold"
                  style={{
                    background: "rgba(0,0,0,.4)",
                    color: "#a1a1aa",
                    border: "1px solid rgba(168,85,247,.2)",
                  }}
                >
                  Clear
                </button>
                <button
                  onClick={() => setBulkDelete(true)}
                  className="px-3 py-1.5 rounded-lg text-[11px] font-bold text-white aw-as-btn"
                  style={{
                    background: "linear-gradient(135deg, #f43f5e, #be123c)",
                    boxShadow: "0 4px 12px -4px rgba(244,63,94,.6)",
                  }}
                >
                  Delete Selected
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Content */}
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 gap-3">
            <div className="w-10 h-10 rounded-full aw-as-spinner" />
            <span
              className="text-[10px] font-mono uppercase tracking-widest"
              style={{ color: "#c084fc" }}
            >
              Loading servers...
            </span>
          </div>
        ) : (
          <>
            {/* Select all row */}
            {filteredServers.length > 0 && (
              <div className="flex items-center gap-3 px-4 mb-3">
                <input
                  type="checkbox"
                  checked={
                    selectedIds.size > 0 &&
                    selectedIds.size === filteredServers.length
                  }
                  onChange={toggleSelectAll}
                  className="w-4 h-4 accent-purple-500 cursor-pointer"
                />
                <span className="text-[10px] font-mono uppercase tracking-widest" style={{ color: "#a1a1aa" }}>
                  Select all ({filteredServers.length})
                </span>
              </div>
            )}

            <div className="grid grid-cols-1 gap-3">
              {filteredServers.map((server, idx) => {
                const status = getStatus(server);
                const isSelected = selectedIds.has(server.id);
                return (
                  <div
                    key={server.id}
                    className="aw-as-glass aw-as-row aw-as-in p-5 flex flex-col md:flex-row items-center justify-between gap-4"
                    style={{
                      animationDelay: `${idx * 0.03}s`,
                      borderColor: isSelected
                        ? "rgba(168,85,247,.6)"
                        : undefined,
                      boxShadow: isSelected
                        ? "0 0 24px -8px rgba(168,85,247,.5)"
                        : undefined,
                    }}
                  >
                    <div className="flex items-center gap-4 flex-1 min-w-0">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleSelect(server.id)}
                        className="w-4 h-4 accent-purple-500 cursor-pointer shrink-0"
                      />

                      <div
                        className="w-12 h-12 rounded-xl flex items-center justify-center border shrink-0"
                        style={
                          status === "suspended"
                            ? {
                                background: "rgba(245,158,11,.12)",
                                border: "1px solid rgba(245,158,11,.35)",
                                boxShadow: "0 0 20px -6px rgba(245,158,11,.5)",
                              }
                            : status === "online"
                            ? {
                                background: "rgba(16,185,129,.12)",
                                border: "1px solid rgba(16,185,129,.35)",
                                boxShadow: "0 0 20px -6px rgba(16,185,129,.5)",
                              }
                            : {
                                background: "rgba(168,85,247,.12)",
                                border: "1px solid rgba(168,85,247,.3)",
                              }
                        }
                      >
                        <Server
                          className="w-5 h-5"
                          style={{
                            color:
                              status === "suspended"
                                ? "#fbbf24"
                                : status === "online"
                                ? "#34d399"
                                : "#c084fc",
                          }}
                        />
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3
                            className="font-bold text-base truncate"
                            style={{ color: "#e9d5ff" }}
                          >
                            {server.name}
                          </h3>
                          {status === "online" && (
                            <span
                              className="text-[9px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-md flex items-center gap-1"
                              style={{
                                background: "rgba(16,185,129,.15)",
                                border: "1px solid rgba(16,185,129,.4)",
                                color: "#34d399",
                              }}
                            >
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                              Online
                            </span>
                          )}
                          {status === "offline" && (
                            <span
                              className="text-[9px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-md flex items-center gap-1"
                              style={{
                                background: "rgba(113,113,122,.2)",
                                border: "1px solid rgba(113,113,122,.4)",
                                color: "#a1a1aa",
                              }}
                            >
                              <Power size={9} />
                              Offline
                            </span>
                          )}
                          {status === "suspended" && (
                            <span
                              className="text-[9px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-md flex items-center gap-1"
                              style={{
                                background: "rgba(245,158,11,.15)",
                                border: "1px solid rgba(245,158,11,.4)",
                                color: "#fbbf24",
                              }}
                            >
                              <PauseCircle size={9} />
                              Suspended
                            </span>
                          )}
                        </div>
                        <div
                          className="flex gap-3 text-xs mt-1 flex-wrap"
                          style={{ color: "#a1a1aa" }}
                        >
                          <span className="font-mono flex items-center gap-1.5">
                            <span
                              className="px-1.5 py-0.5 rounded"
                              style={{
                                background: "rgba(168,85,247,.1)",
                                color: "#c084fc",
                                border: "1px solid rgba(168,85,247,.25)",
                              }}
                            >
                              {server.type || "paper"}
                            </span>
                            {server.version || "latest"}
                          </span>
                          <span className="flex items-center gap-1.5">
                            <Users size={11} style={{ color: "rgba(168,85,247,.6)" }} />
                            Owner:{" "}
                            <span style={{ color: "#c084fc" }}>
                              {getUsername(server.owner)}
                            </span>
                          </span>
                          <span className="font-mono flex items-center gap-1.5">
                            {server.ram || "?"}GB / {server.cpu || "?"}%
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {/* Quick actions */}
                      {status === "online" && (
                        <>
                          <button
                            onClick={() => handleServerAction(server.id, "restart")}
                            className="aw-as-btn p-2 rounded-xl"
                            style={{
                              background: "rgba(0,0,0,.4)",
                              border: "1px solid rgba(168,85,247,.25)",
                              color: "#c084fc",
                            }}
                            title="Restart"
                          >
                            <RefreshCw className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleServerAction(server.id, "stop")}
                            className="aw-as-btn p-2 rounded-xl"
                            style={{
                              background: "rgba(0,0,0,.4)",
                              border: "1px solid rgba(244,63,94,.25)",
                              color: "#f43f5e",
                            }}
                            title="Stop"
                          >
                            <Square className="w-4 h-4" />
                          </button>
                        </>
                      )}
                      {status === "offline" && (
                        <button
                          onClick={() => handleServerAction(server.id, "start")}
                          className="aw-as-btn p-2 rounded-xl"
                          style={{
                            background: "rgba(0,0,0,.4)",
                            border: "1px solid rgba(16,185,129,.25)",
                            color: "#34d399",
                          }}
                          title="Start"
                        >
                          <Play className="w-4 h-4" />
                        </button>
                      )}

                      <ActionMenu
                        server={server}
                        setEditingServer={setEditingServer}
                        setRam={setRam}
                        setCpu={setCpu}
                        setDisk={setDisk}
                        setSuspendingServer={setSuspendingServer}
                        setSuspendDuration={setSuspendDuration}
                        setDeletingServer={setDeletingServer}
                      />

                      <Link
                        to={`/servers/${server.id}`}
                        className="aw-as-btn flex items-center gap-2 px-4 py-2 rounded-xl text-white text-sm font-semibold shrink-0"
                        style={{
                          background: "linear-gradient(135deg, #a855f7, #7e22ce)",
                          boxShadow: "0 4px 16px -4px rgba(168,85,247,.6)",
                        }}
                      >
                        <span className="hidden sm:inline">Console</span>
                        <ChevronRight className="w-4 h-4" />
                      </Link>
                    </div>
                  </div>
                );
              })}

              {filteredServers.length === 0 && (
                <div className="aw-as-glass p-12 text-center aw-as-in">
                  <div
                    className="w-16 h-16 mx-auto mb-4 rounded-2xl flex items-center justify-center"
                    style={{
                      background: "rgba(168,85,247,.08)",
                      border: "1px solid rgba(168,85,247,.2)",
                    }}
                  >
                    <Server size={28} style={{ color: "rgba(192,132,252,.5)" }} />
                  </div>
                  <p className="font-semibold text-sm" style={{ color: "#e9d5ff" }}>
                    No servers found
                  </p>
                  <p className="text-xs mt-1" style={{ color: "#a1a1aa" }}>
                    {searchTerm || filterKey !== "all"
                      ? "Try adjusting your search or filters."
                      : "No servers have been created yet."}
                  </p>
                </div>
              )}
            </div>
          </>
        )}

        {/* ═══ EDIT MODAL ═══ */}
        <AnimatePresence>
          {editingServer && (
            <div
              className="fixed inset-0 z-50 flex items-center justify-center p-4"
              style={{
                background: "rgba(0,0,0,.75)",
                backdropFilter: "blur(12px)",
              }}
              onClick={() => setEditingServer(null)}
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.95, filter: "blur(6px)" }}
                animate={{ opacity: 1, scale: 1, filter: "blur(0)" }}
                exit={{ opacity: 0, scale: 0.95, filter: "blur(6px)" }}
                className="aw-as-modal p-6 max-w-md w-full"
                onClick={(e) => e.stopPropagation()}
              >
                <h2
                  className="text-lg font-bold mb-4 flex items-center gap-2"
                  style={{ color: "#e9d5ff" }}
                >
                  <span
                    className="w-8 h-8 rounded-lg flex items-center justify-center"
                    style={{
                      background: "rgba(168,85,247,.12)",
                      border: "1px solid rgba(168,85,247,.3)",
                      color: "#c084fc",
                    }}
                  >
                    <Settings size={16} />
                  </span>
                  Edit Resources
                  <span
                    className="text-xs font-mono"
                    style={{ color: "rgba(192,132,252,.7)" }}
                  >
                    {editingServer.name}
                  </span>
                </h2>
                <form onSubmit={handleUpdateResources}>
                  <div className="space-y-4 mb-6">
                    {[
                      { label: "RAM (GB)", value: ram, set: setRam, min: "1" },
                      { label: "CPU (%)", value: cpu, set: setCpu, min: "50" },
                      { label: "Disk (GB)", value: disk, set: setDisk, min: "1" },
                    ].map((field) => (
                      <div key={field.label}>
                        <label
                          className="block text-[10px] font-bold uppercase tracking-widest mb-1.5"
                          style={{ color: "#c084fc" }}
                        >
                          {field.label}
                        </label>
                        <input
                          type="number"
                          value={field.value}
                          onChange={(e) => field.set(e.target.value)}
                          required
                          min={field.min}
                          className="aw-as-input w-full rounded-xl px-4 py-2.5 text-sm"
                          style={{
                            background: "rgba(0,0,0,.5)",
                            border: "1px solid rgba(168,85,247,.25)",
                            color: "#e9d5ff",
                            caretColor: "#c084fc",
                          }}
                        />
                      </div>
                    ))}
                  </div>
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setEditingServer(null)}
                      className="aw-as-btn px-4 py-2 rounded-xl text-xs font-semibold"
                      style={{
                        background: "rgba(0,0,0,.4)",
                        border: "1px solid rgba(168,85,247,.2)",
                        color: "#a1a1aa",
                      }}
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="aw-as-btn px-4 py-2 rounded-xl text-xs font-bold text-white"
                      style={{
                        background: "linear-gradient(135deg, #a855f7, #7e22ce)",
                        boxShadow: "0 4px 16px -4px rgba(168,85,247,.6)",
                      }}
                    >
                      Save Changes
                    </button>
                  </div>
                </form>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* ═══ SUSPEND MODAL ═══ */}
        <AnimatePresence>
          {suspendingServer && (
            <div
              className="fixed inset-0 z-50 flex items-center justify-center p-4"
              style={{
                background: "rgba(0,0,0,.75)",
                backdropFilter: "blur(12px)",
              }}
              onClick={() => setSuspendingServer(null)}
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.95, filter: "blur(6px)" }}
                animate={{ opacity: 1, scale: 1, filter: "blur(0)" }}
                exit={{ opacity: 0, scale: 0.95, filter: "blur(6px)" }}
                className="aw-as-modal p-6 max-w-md w-full"
                onClick={(e) => e.stopPropagation()}
              >
                <h2
                  className="text-lg font-bold mb-4 flex items-center gap-2"
                  style={{ color: "#fcd34d" }}
                >
                  <span
                    className="w-8 h-8 rounded-lg flex items-center justify-center"
                    style={{
                      background: "rgba(245,158,11,.15)",
                      border: "1px solid rgba(245,158,11,.4)",
                      color: "#fbbf24",
                    }}
                  >
                    <PauseCircle size={16} />
                  </span>
                  Manage Suspension
                  <span
                    className="text-xs font-mono"
                    style={{ color: "rgba(252,211,77,.7)" }}
                  >
                    {suspendingServer.name}
                  </span>
                </h2>
                <form onSubmit={handleUpdateSuspend}>
                  <div className="mb-6">
                    <label
                      className="block text-[10px] font-bold uppercase tracking-widest mb-2"
                      style={{ color: "#c084fc" }}
                    >
                      Suspension Duration
                    </label>
                    <select
                      value={suspendDuration}
                      onChange={(e) => setSuspendDuration(e.target.value)}
                      className="aw-as-input aw-as-select w-full rounded-xl px-4 py-3 text-sm"
                      style={{
                        background: "rgba(0,0,0,.5)",
                        border: "1px solid rgba(168,85,247,.25)",
                        color: "#e9d5ff",
                        cursor: "pointer",
                      }}
                    >
                      <option value="null">Not Suspended (Active)</option>
                      <option value="24_hours">24 Hours</option>
                      <option value="1_week">1 Week</option>
                      <option value="1_month">1 Month</option>
                      <option value="2_months">2 Months</option>
                      <option value="permanent">Permanent</option>
                    </select>
                  </div>
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setSuspendingServer(null)}
                      className="aw-as-btn px-4 py-2 rounded-xl text-xs font-semibold"
                      style={{
                        background: "rgba(0,0,0,.4)",
                        border: "1px solid rgba(168,85,247,.2)",
                        color: "#a1a1aa",
                      }}
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="aw-as-btn px-4 py-2 rounded-xl text-xs font-bold text-white"
                      style={{
                        background: "linear-gradient(135deg, #f59e0b, #d97706)",
                        boxShadow: "0 4px 16px -4px rgba(245,158,11,.6)",
                      }}
                    >
                      Apply
                    </button>
                  </div>
                </form>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* ═══ DELETE MODAL ═══ */}
        <AnimatePresence>
          {deletingServer && (
            <div
              className="fixed inset-0 z-50 flex items-center justify-center p-4"
              style={{
                background: "rgba(0,0,0,.75)",
                backdropFilter: "blur(12px)",
              }}
              onClick={() => setDeletingServer(null)}
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.95, filter: "blur(6px)" }}
                animate={{ opacity: 1, scale: 1, filter: "blur(0)" }}
                exit={{ opacity: 0, scale: 0.95, filter: "blur(6px)" }}
                className="aw-as-modal p-6 max-w-md w-full"
                style={{ borderColor: "rgba(244,63,94,.4)" }}
                onClick={(e) => e.stopPropagation()}
              >
                <h2
                  className="text-lg font-bold mb-2 flex items-center gap-2"
                  style={{ color: "#fda4af" }}
                >
                  <span
                    className="w-8 h-8 rounded-lg flex items-center justify-center"
                    style={{
                      background: "rgba(244,63,94,.15)",
                      border: "1px solid rgba(244,63,94,.4)",
                      color: "#f43f5e",
                    }}
                  >
                    <AlertTriangle size={16} />
                  </span>
                  Delete Server?
                </h2>
                <p
                  className="text-sm mb-6 leading-relaxed"
                  style={{ color: "rgba(253,164,175,.85)" }}
                >
                  Are you sure you want to permanently delete{" "}
                  <strong style={{ color: "#fda4af" }}>{deletingServer.name}</strong>
                  ? This action cannot be undone and will destroy all data.
                </p>
                <div className="flex justify-end gap-2">
                  <button
                    onClick={() => setDeletingServer(null)}
                    className="aw-as-btn px-4 py-2 rounded-xl text-xs font-semibold"
                    style={{
                      background: "rgba(0,0,0,.4)",
                      border: "1px solid rgba(168,85,247,.2)",
                      color: "#a1a1aa",
                    }}
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleDelete}
                    className="aw-as-btn px-4 py-2 rounded-xl text-xs font-bold text-white"
                    style={{
                      background: "linear-gradient(135deg, #f43f5e, #be123c)",
                      boxShadow: "0 4px 16px -4px rgba(244,63,94,.6)",
                    }}
                  >
                    Yes, Delete
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* ═══ BULK DELETE MODAL ═══ */}
        <AnimatePresence>
          {bulkDelete && (
            <div
              className="fixed inset-0 z-50 flex items-center justify-center p-4"
              style={{
                background: "rgba(0,0,0,.75)",
                backdropFilter: "blur(12px)",
              }}
              onClick={() => setBulkDelete(false)}
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="aw-as-modal p-6 max-w-md w-full"
                style={{ borderColor: "rgba(244,63,94,.4)" }}
                onClick={(e) => e.stopPropagation()}
              >
                <h2
                  className="text-lg font-bold mb-2 flex items-center gap-2"
                  style={{ color: "#fda4af" }}
                >
                  <AlertTriangle size={18} />
                  Delete {selectedIds.size} Servers?
                </h2>
                <p className="text-sm mb-6" style={{ color: "rgba(253,164,175,.85)" }}>
                  This will permanently delete all selected servers and their data. This cannot be undone.
                </p>
                <div className="flex justify-end gap-2">
                  <button
                    onClick={() => setBulkDelete(false)}
                    className="aw-as-btn px-4 py-2 rounded-xl text-xs font-semibold"
                    style={{
                      background: "rgba(0,0,0,.4)",
                      border: "1px solid rgba(168,85,247,.2)",
                      color: "#a1a1aa",
                    }}
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleBulkDelete}
                    className="aw-as-btn px-4 py-2 rounded-xl text-xs font-bold text-white"
                    style={{
                      background: "linear-gradient(135deg, #f43f5e, #be123c)",
                    }}
                  >
                    Delete All
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </>
  );
}

// ═══════════════════════════════════════════════
// ACTION MENU COMPONENT
// ═══════════════════════════════════════════════
function ActionMenu({
  server,
  setEditingServer,
  setRam,
  setCpu,
  setDisk,
  setSuspendingServer,
  setSuspendDuration,
  setDeletingServer,
}: any) {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const handleClick = () => setOpen(false);
    if (open) document.addEventListener("click", handleClick);
    return () => document.removeEventListener("click", handleClick);
  }, [open]);

  return (
    <div className="relative" onClick={(e) => e.stopPropagation()}>
      <button
        onClick={() => setOpen(!open)}
        className="aw-as-btn p-2 rounded-xl"
        style={{
          background: "rgba(0,0,0,.4)",
          border: "1px solid rgba(168,85,247,.25)",
          color: "#c084fc",
        }}
        title="More Actions"
      >
        <MoreVertical className="w-5 h-5" />
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            transition={{ duration: 0.15 }}
            className="aw-as-ctx-menu absolute right-0 mt-2 w-52 z-50 flex flex-col py-1.5"
          >
            <button
              onClick={() => {
                setEditingServer(server);
                setRam(server.ram?.toString() || "4");
                setCpu(server.cpu?.toString() || "150");
                setDisk(server.disk?.toString() || "10");
                setOpen(false);
              }}
              className="aw-as-btn flex items-center px-3.5 py-2.5 text-xs font-medium text-left"
              style={{ color: "#e9d5ff" }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = "rgba(168,85,247,.15)";
                e.currentTarget.style.color = "#c084fc";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = "transparent";
                e.currentTarget.style.color = "#e9d5ff";
              }}
            >
              <Edit2 className="w-4 h-4 mr-3" style={{ color: "#c084fc" }} />
              Edit Resources
            </button>

            <button
              onClick={() => {
                setSuspendingServer(server);
                setSuspendDuration(server.suspendDuration || "null");
                setOpen(false);
              }}
              className="aw-as-btn flex items-center px-3.5 py-2.5 text-xs font-medium text-left"
              style={{ color: "#fbbf24" }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = "rgba(245,158,11,.15)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = "transparent";
              }}
            >
              <PauseCircle className="w-4 h-4 mr-3" style={{ color: "#fbbf24" }} />
              {server.suspended ? "Manage Suspension" : "Suspend Server"}
            </button>

            <div
              className="my-1 mx-2"
              style={{ height: 1, background: "rgba(168,85,247,.15)" }}
            />

            <button
              onClick={() => {
                setDeletingServer(server);
                setOpen(false);
              }}
              className="aw-as-btn flex items-center px-3.5 py-2.5 text-xs font-medium text-left"
              style={{ color: "#fda4af" }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = "rgba(244,63,94,.15)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = "transparent";
              }}
            >
              <Trash2 className="w-4 h-4 mr-3" />
              Delete Server
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}